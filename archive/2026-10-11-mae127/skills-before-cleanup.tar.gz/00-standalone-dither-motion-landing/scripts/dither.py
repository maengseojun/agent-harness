#!/usr/bin/env python3
"""Convert local imagery to opaque two-color PNG/APNG using an existing FFmpeg."""
import argparse
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import tempfile
import zlib


def palette_png(ink):
    """Make the 256-pixel fixed RGB palette accepted by FFmpeg's paletteuse."""
    def chunk(kind, data):
        return (struct.pack('>I', len(data)) + kind + data
                + struct.pack('>I', zlib.crc32(kind + data)))
    # ponytail: opaque white paper; add alpha handling when overlays require it.
    pixels = bytes(ink) + bytes([255, 255, 255]) * 15
    raw = (b'\0' + pixels) * 16
    return (b'\x89PNG\r\n\x1a\n'
            + chunk(b'IHDR', struct.pack('>IIBBBBB', 16, 16, 8, 2, 0, 0, 0))
            + chunk(b'IDAT', zlib.compress(raw)) + chunk(b'IEND', b''))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('output', type=Path, help='.png or .apng; never overwritten')
    parser.add_argument('--still', action='store_true', help='Convert one frame only')
    parser.add_argument('--width', type=int, default=640, help='Working grid width')
    parser.add_argument('--pixel-size', type=int, default=2, help='Integer enlargement')
    parser.add_argument('--fps', type=int, default=8)
    parser.add_argument('--seconds', type=float)
    parser.add_argument('--ink', default='#6ec1ea')
    args = parser.parse_args()
    if not shutil.which('ffmpeg'):
        parser.error('FFmpeg is required; this helper does not install it')
    if not args.source.is_file():
        parser.error('Source must be an existing local file')
    if args.output.suffix.lower() not in ('.png', '.apng'):
        parser.error('Output must end in .png or .apng')
    if args.width < 2 or args.pixel_size < 1 or not 1 <= args.fps <= 60:
        parser.error('Width >= 2, pixel size >= 1, and fps 1..60 are required')
    if args.seconds is not None and not 0 < args.seconds < float('inf'):
        parser.error('Seconds must be finite and positive')
    if not re.fullmatch(r'#[0-9a-fA-F]{6}', args.ink):
        parser.error('Ink must be a six-digit hex color, for example #6ec1ea')
    poster = args.output.with_name(args.output.stem + '-still.png')
    outputs = [args.output] if args.still else [args.output, poster]
    if any(path.exists() for path in outputs):
        parser.error('An output already exists; choose a new filename')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    ink = tuple(int(args.ink[i:i + 2], 16) for i in (1, 3, 5))
    ramp = ':'.join(f'{channel}={value}+val*{255-value}/255'
                    for channel, value in zip('rgb', ink))
    rate = '' if args.still else f'fps={args.fps},'
    filters = (f'[0:v]{rate}scale={args.width}:-2:flags=area,'
               f'format=gray,lutrgb={ramp}[tones];'
               '[tones][1:v]paletteuse=dither=bayer:bayer_scale=2,format=rgba,'
               f'scale=iw*{args.pixel_size}:ih*{args.pixel_size}:flags=neighbor[out]')
    with tempfile.TemporaryDirectory(dir=args.output.parent) as directory:
        palette = Path(directory) / 'palette.png'
        encoded = Path(directory) / 'encoded.png'
        static = Path(directory) / 'still.png'
        palette.write_bytes(palette_png(ink))
        command = ['ffmpeg', '-hide_banner', '-loglevel', 'error', '-n',
                   '-i', str(args.source.resolve()), '-i', str(palette),
                   '-filter_complex', filters, '-map', '[out]', '-an']
        if args.seconds is not None:
            command += ['-t', str(args.seconds)]
        if args.still:
            command += ['-frames:v', '1', '-c:v', 'png', '-update', '1']
        else:
            command += ['-c:v', 'apng', '-plays', '0', '-f', 'apng']
        subprocess.run(command + [str(encoded.resolve())], check=True)
        if not args.still:
            # A single input frame must not masquerade as an animated deliverable.
            if b'acTL' not in encoded.read_bytes()[:128]:
                raise ValueError('Output has no animation; use --still for an image')
            subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-n',
                            '-i', str(encoded.resolve()), '-frames:v', '1',
                            '-update', '1', str(static.resolve())], check=True)
        # Exclusive links publish completed files without overwriting another run.
        for source, output in zip([encoded, static], outputs):
            os.link(source, output)
    for output in outputs:
        print(f'{output.resolve()} ({output.stat().st_size} bytes)')


if __name__ == '__main__':
    try:
        main()
    except (subprocess.CalledProcessError, ValueError, OSError) as error:
        raise SystemExit(str(error)) from None
