#!/usr/bin/env python3
"""One end-to-end check: moving tones -> fixed-palette APNG + matching poster."""
from pathlib import Path
import struct
import subprocess
import sys
import tempfile


def run(*args):
    return subprocess.run(args, check=True, capture_output=True).stdout


def chunks(path):
    raw = path.read_bytes()
    assert raw[:8] == b'\x89PNG\r\n\x1a\n'
    offset = 8
    result = []
    while offset < len(raw):
        size = struct.unpack_from('>I', raw, offset)[0]
        result.append((raw[offset + 4:offset + 8], raw[offset + 8:offset + 8 + size]))
        offset += size + 12
    return result


def main():
    helper = str(Path(__file__).with_name('dither.py'))
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        source, output = root / 'moving.mkv', root / 'loop.png'
        run('ffmpeg', '-hide_banner', '-loglevel', 'error', '-f', 'lavfi', '-i',
            "nullsrc=s=48x32:r=8:d=1,geq=lum='255*X/W+32*sin(N*PI/4)':cb=128:cr=128",
            '-c:v', 'ffv1', str(source))
        command = [sys.executable, helper, str(source), str(output), '--width', '24',
                   '--fps', '8', '--ink', '#6ec1ea']
        run(*command)
        metadata = dict(chunks(output))
        assert struct.unpack_from('>II', metadata[b'IHDR']) == (48, 32)
        assert struct.unpack('>II', metadata[b'acTL']) == (8, 0)
        duration = sum((n / (d or 100)) for n, d in
                       (struct.unpack_from('>HH', data, 20)
                        for kind, data in chunks(output) if kind == b'fcTL'))
        assert abs(duration - 1) < 0.001
        raw = run('ffmpeg', '-hide_banner', '-loglevel', 'error', '-i', str(output),
                  '-frames:v', '8', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-')
        colors = {raw[i:i + 3] for i in range(0, len(raw), 3)}
        assert colors == {bytes((110, 193, 234)), b'\xff\xff\xff'}, colors
        frame_bytes = 48 * 32 * 3
        assert len(raw) == frame_bytes * 8
        assert raw[:frame_bytes] != raw[frame_bytes:2 * frame_bytes]
        poster = root / 'loop-still.png'
        assert b'acTL' not in dict(chunks(poster))
        still = run('ffmpeg', '-hide_banner', '-loglevel', 'error', '-i', str(poster),
                    '-frames:v', '1', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-')
        assert still == raw[:frame_bytes]
        first = output.read_bytes()
        assert subprocess.run(command, capture_output=True).returncode != 0
        assert output.read_bytes() == first
        single = root / 'single.png'
        run(sys.executable, helper, str(poster), str(single), '--still', '--width', '24')
        assert b'acTL' not in dict(chunks(single))
        no_motion = root / 'no-motion.png'
        assert subprocess.run([sys.executable, helper, str(poster), str(no_motion)],
                              capture_output=True).returncode != 0
        assert not no_motion.exists()
        assert subprocess.run([sys.executable, helper, str(source), str(root / 'bad.png'),
                               '--ink', 'blue'], capture_output=True).returncode != 0
    print('PASS: palette, dimensions, frame count, timing, motion, poster, still, no overwrite')


if __name__ == '__main__':
    main()
