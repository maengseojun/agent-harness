# Production recipes

## Composition and prompts

Generate the image for its place in the layout. A useful hero prompt specifies
the camera, tonal shape, foreground placement, background, quiet text region,
and crop. Start with smooth tonal detail rather than asking a model to invent
every final dither dot. Choose the subject to express the product's promise.

Example for a restrained atmospheric hero; adapt the metaphor and palette:

> Wide, locked composition of soft cloud masses concentrated along the bottom
> corners, sparse upper field and a completely quiet central area for a large
> website heading. White background, clear silhouettes, smooth grayscale tonal
> detail, restrained editorial composition. No text, logos, interface, or border.

Example movement prompt:

> Keep the camera and framing locked. Very slow internal cloud drift, preserving
> the central empty space and original silhouettes. No zoom, pan, cuts, text,
> new objects, or abrupt lighting changes. Start and end in compatible states
> for a subtle background loop.

A seamless-loop instruction is a request, not a guarantee. Inspect first/last
frames, exposure and shape continuity. Choose another segment or blend a seam
only if the resulting ghosting is acceptable. Ping-pong can suit drifting haze;
it usually exposes unnatural reversal in waves, falling particles, or traffic.

Motion first, dithering second is a practical default. Image-to-video on already
dithered art can reinterpret dots and produce crawling texture. If that order is
requested, inspect its result and stabilize or re-dither only as needed.

## Dither and encode

Dithering represents tonal density with a limited color palette. A dotted CSS
background and `image-rendering: pixelated` do not perform this conversion.

Downsample to the intended dot grid, map luminance into the chosen palette,
threshold with a stable pattern, then scale by an integer using nearest-neighbor.
Use the same palette, contrast and threshold coordinates across video frames.
Changing the seed or independently generating a palette per frame can flicker.
Ordered Bayer patterns are regular and fast; fixed blue-noise thresholds produce
a less visibly gridded stipple. Error diffusion can look good in stills but should
be tested for temporal shimmer in video.

The included helper requires Python's standard library and an existing FFmpeg
with `paletteuse` and APNG support; it installs nothing and makes no network calls.
Paths are relative to the skill directory in these examples:

```sh
python3 scripts/dither.py source.mp4 hero.png --width 640 --pixel-size 2 --fps 8 --ink '#6ec1ea'
python3 scripts/dither.py source.png hero-still.png --still --width 640 --pixel-size 2 --ink '#6ec1ea'
python3 scripts/test_dither.py
```

The first command writes an infinitely looping APNG and `hero-still.png` using its
first encoded frame. The second processes one frame only. `--width` is the working
grid width; `--pixel-size 2` produces a 1280-pixel-wide file. `--seconds` optionally
limits a video segment; trim the start beforehand if necessary. The helper refuses
to overwrite existing output. Choose different filenames for experiments.

Its deliberate limits: two opaque colors, white paper, fixed Bayer pattern, and
no loop-seam repair. It does not generate motion, preserve source alpha, copy the
reference's blue-noise appearance, or prove a clip is seamless. Use a per-task
alpha-aware or fixed blue-noise pipeline when the composition needs those features.

Start around 6–12 fps for slow atmospheric motion and inspect the result at its
actual display size. This is a starting range, not a required frame rate. Try the
smallest useful grid first; measure the encoded bytes and visual quality.

| Delivery | Choose when |
| --- | --- |
| PNG | The approved composition is static or used as a poster. |
| APNG | A short, sparse loop needs crisp dots and predictable palette/alpha fidelity. |
| Animated WebP | Lossless or tested lossy encoding improves real download size. |
| MP4/WebM with a poster | A larger scene compresses better as video and exact dot edges are less important. |
| CSS / SVG / Canvas | Movement comes from inspectable geometry or states rather than footage. |

Compare measured files instead of declaring a universal best format. APNGs can be
much larger than video, and native image elements provide no play/pause timeline.

## Browser delivery and motion

Use a matching background and static underlay. Reserve intrinsic dimensions. For
responsive assets, a `picture` can choose a static source before the animated one:

```html
<picture aria-hidden="true">
  <source media="(prefers-reduced-motion: reduce)" srcset="hero-still.png">
  <img src="hero.png" width="1280" height="720" alt="">
</picture>
```

Adapt dimensions and responsive sources to the actual exported assets. Add
`image-rendering: pixelated` where appropriate, and avoid fractional CSS scaling
when it creates uneven dots. At narrow widths, crop or recompose deliberately
instead of shrinking every desktop detail until it disappears.

This snippet covers reduced-motion source selection only. For continuous autoplay
that qualifies under WCAG 2.2.2, provide a keyboard-accessible pause/resume button.
For APNG/WebP, switch to the poster and restore the animated source to resume;
`animation-play-state` cannot pause frames inside an image. Ensure responsive
`source`/`srcset` selection cannot override the paused poster. Native `video` can
use `pause()`/`play()`; account for rejected autoplay promises. Reduced motion
should take priority and update when the OS preference changes.

For Canvas diagrams, animate the underlying states at a bounded working resolution,
then render into a capped device-pixel-ratio surface. Tie every move to a product
rule. Use a deterministic threshold map and bounded delta time. Pause with
`IntersectionObserver` and document visibility, update an explanatory static
frame under reduced motion, and clean up on unmount. Keep labels and essential
claims available in HTML.

## Sources

- [FFmpeg paletteuse, dithering modes and Bayer scale](https://ffmpeg.org/ffmpeg-filters.html#paletteuse)
- [FFmpeg APNG muxer and plays](https://ffmpeg.org/ffmpeg-formats.html#apng)
- [MDN image formats](https://developer.mozilla.org/en-US/docs/Web/Media/Guides/Formats/Image_types)
- [MDN reduced motion](https://developer.mozilla.org/en-US/docs/Web/CSS/@media/prefers-reduced-motion)
- [W3C pause, stop, hide](https://www.w3.org/WAI/WCAG22/Understanding/pause-stop-hide.html)
