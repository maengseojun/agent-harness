# watermark reference inspection

Inspected 2026-09-27 at <https://desk-swart.vercel.app/>. This records one reference,
not a template every future page must follow. Recheck deployed assets when exact
implementation matters: bundle filenames and content can change.

## Art direction observed

- A mostly white field, large black headings, and a restrained blue accent.
- Sparse clouds framing a quiet central hero; a sea texture at the closing section.
- Pixel or stipple textures repeated in imagery and explanatory diagrams.
- Large section spacing, direct claims, and small monospace diagram labels.
- Movement helps explain disposal, counterparty gating, and changing spreads.

These are design observations. The conclusion that consistency and quiet text
space make the page effective is editorial interpretation, not measured usability.

## Verified implementation

Public HTML loaded `assets/index-D1jUYPiz.js` and `assets/index-DnXY3qUg.css`.
Inspection of the deployed bundle, browser DOM, and PNG chunks found:

| Component | Evidence |
| --- | --- |
| Clouds | `clouds-1600.png`: indexed APNG, 1600 × 686, 58 frames, about 9.667 seconds, infinite plays, 669603 bytes. |
| Cloud poster | `clouds-1600-still.png`: static PNG, 10694 bytes. |
| Sea | `sea-1600.png`: indexed APNG, 1600 × 446, 26 frames, 3.25 seconds, infinite plays, 203206 bytes. |
| Sea poster | `sea-1600-still.png`: static PNG, 8295 bytes. |
| Responsive imagery | `picture` selects widths 1280, 1600, and 1920; reduced-motion sources select still PNGs. |
| Initial paint | A poster remains under the moving image; `onLoad` enables a 0.4-second opacity transition. |
| Pixel display | CSS sets `image-rendering: pixelated`; Canvas disables image smoothing. |
| Explanatory diagrams | Four 2D canvases, timed state updates, `requestAnimationFrame`, and `IntersectionObserver`. |
| Diagram dithering | A cached 64 × 64 threshold map, seeded occupancy and Gaussian-density updates, and thresholded ink/accent buffers. |

The threshold generator resembles a void-and-cluster blue-noise construction.
That name is an inference from the code; the original authoring algorithm for the
cloud/sea files is unknown. The helper supplied with this skill uses Bayer ordered
dithering as a simple reproducible starting point, not the reference's exact texture.

There was no `video` element or WebGL shader in the inspected landing section.
At 390 × 844, the headline remained within the viewport and the browser selected
the 1280 variants. Reloading with reduced motion selected still images and rendered
static diagrams. This does not establish behavior in every browser or under a
live preference toggle.

## Provenance and reuse boundaries

The user reports that the creator used Codex and Higgsfield. Public assets verify
the delivery mechanism, not the generating service, model, prompt, source footage,
or processing order. Do not present those authoring details as independently proven.
Do not package the reference's artwork, fonts, copy, or minified code in new output;
create original assets and implement the transferable techniques.

## Primary sources

- [Live reference](https://desk-swart.vercel.app/)
- [Deployed JavaScript](https://desk-swart.vercel.app/assets/index-D1jUYPiz.js)
- [Deployed CSS](https://desk-swart.vercel.app/assets/index-DnXY3qUg.css)
- [Cloud motion asset](https://desk-swart.vercel.app/landing/clouds-1600.png)
- [Sea motion asset](https://desk-swart.vercel.app/landing/sea-1600.png)
- [APNG format and browser delivery](https://developer.mozilla.org/en-US/docs/Web/Media/Guides/Formats/Image_types#apng_animated_portable_network_graphics)
