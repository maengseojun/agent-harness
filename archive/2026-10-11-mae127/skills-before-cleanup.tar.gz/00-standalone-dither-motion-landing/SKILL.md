---
name: dither-motion-landing
description: Create or refine landing pages whose visual identity uses original dithered imagery and purposeful motion. Use for AI image and video asset workflows, pixel or stipple art direction, and matching browser animations; select other styles when requested.
---

# Dither Motion Landing

Create a coherent landing page, from original artwork through browser verification.
Use this workflow when the user wants dithered imagery and motion; it is not a
universal template for landing pages. Preserve the existing site's stack and brand.

## Establish the visual direction

Inspect the reference at desktop and mobile sizes, including movement over time.
Separate visible art direction from verified implementation and user-reported
provenance. File extensions do not establish whether an image animates.
For the motivating watermark example, read
[reference inspection](references/watermark-inspection.md) when relevant.

Choose the page's audience, central promise, dominant visual metaphor, and reading
order before making assets. Make routine design decisions autonomously. Carry a
small set of palette, dot-size, type, spacing, and motion choices across artwork,
diagrams, and UI. Reserve quiet space for live headings and calls to action.
Keep marketing text in HTML rather than baking it into images.

## Choose the right kind of movement

| Intended effect | Preferred implementation |
| --- | --- |
| A flat composition drifting or revealing | Static artwork with CSS transforms or masks. |
| Clouds, water, fabric, or other internal movement | A short generated or supplied clip, processed into a dithered loop. |
| Explaining a product rule, flow, or comparison | SVG or Canvas driven by explicit, inspectable state. |

Reuse existing animation infrastructure. Native CSS, SVG, Canvas, and media are
usually sufficient. Add WebGL or another library only for a demonstrated need.
Do not turn protocol diagrams into AI-generated footage or present illustrative
motion and counters as real production events.

## Produce and process assets

Read [production recipes](references/production.md) for prompt examples, dithering,
format selection, browser integration, and the included conversion helper.

Use the user's chosen image provider. Otherwise prefer the installed
`chatgpt-web-image` integration when its current instructions allow it and its
Images surface is ready. Discover and read current tool contracts before calling
them. If login or quota blocks it, report that result and use another available
image tool within the authorized task. Do not reconfigure accounts or projects
merely to obtain a preview.

For Higgsfield movement, check the connection, discover a current image-to-video
model, inspect its supported media roles and parameters, and apply the tool's
cost and execution rules. Upload and confirm only the selected asset when
required. Submit a bounded run, wait for completion, and inspect the returned
artifact; a job ID is not a finished video. Do not hardcode model IDs, prices,
unlimited access, or account availability in this skill.

Normally animate clean artwork first and dither all frames afterward with one
palette and a stable threshold pattern. If a supplied asset is already dithered,
preserve it and inspect temporal stability; do not regenerate it automatically.
Judge the loop seam, composition, and text contrast before integrating it.

Preserve the clean source, processed motion, and matching static poster. Supply
variants for the actual display sizes, with measured byte sizes and frame counts.
The helper starts with opaque, two-color ordered dithering; choose another path
when alpha transparency or a blue-noise texture is essential.

## Integrate and verify

Use a static first paint and reveal motion after decoding. Reserve image dimensions
to avoid layout shifts. Keep dots crisp and their apparent scale consistent across
breakpoints. Match the surrounding background to opaque artwork.

Honor `prefers-reduced-motion` with a meaningful static composition and handle
preference changes while the page is open. For qualifying continuous autoplay,
provide an accessible pause/resume control; APNG needs an image-source swap to
pause. Stop scripted animation when offscreen or the document is hidden, bound
Canvas resolution, and release observers and animation callbacks on cleanup.
Provide an HTML explanation for meaningful Canvas diagrams.

Inspect the finished page at desktop and narrow mobile widths, in motion and with
reduced motion. Check slow or failed media loading, headline legibility, loop seams,
dot shimmer, focus visibility, horizontal overflow, and actual download sizes.
Run the narrow project checks for changed code; run the helper's self-check after
changing its processing logic. Correct observed defects before delivery.

Deliver the actual page or requested assets, their editable sources and paths,
checks performed, and any untested provider or browser boundary. Creating this
skill alone does not prove a future provider generation or authorize deployment.
