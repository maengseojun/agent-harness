---
name: google-flow-credits
description: Use Google Flow's website through Codex's supported Chrome browser controls to create images or videos with the user's existing Flow subscription credits. Use when the user names Google Flow, Flow 구독 크레딧, or explicitly requests this credit source; also handle read-only Flow access and balance checks. Do not route generic image requests here or substitute Vertex, Gemini API, OpenAI, or Higgsfield billing.
---

# Google Flow credits

Use the user's existing authenticated Chrome session and Flow's visible UI. This skill is a workflow for Codex browser tools, not a Flow API or an MCP server. Reply in the user's language.

## Scope and access

- Use `mcp__cua_repl.js` and only APIs documented by that tool in the current task. Read [references/browser-workflow.md](references/browser-workflow.md) before the first browser action. A skill file does not provide browser access by itself.
- If the supported browser tool or Chrome connection is unavailable, report exactly which is missing and the smallest next step. When Chrome is connected, reuse a Flow tab or open one through the documented entry point; if the Flow workspace still cannot be reached, report that access blocker. Do not install tools, modify configuration, grant permissions, start remote debugging, or switch to shell-based browser automation to work around it.
- Reuse an existing Flow tab where possible. Observe the current page before navigating or typing; preserve drafts and existing projects. Verify the intended account and project in the visible UI. If multiple plausible accounts/projects remain, ask the user to choose before preparing generation.
- Confirm access to an actual Flow workspace, not just a marketing page or a Google avatar. Observe the displayed plan and remaining credits when available. Never assume a remembered balance, model list, tab ID, or account remains current.
- Stop for user action if sign-in, CAPTCHA, new permissions, security warnings, or acceptance of terms blocks access. Do not read credential stores, cookies, tokens, browser profiles, internal app state, or network traffic; do not export sessions or call private APIs.
- Do not install or execute third-party Flow MCP wrappers. Do not replace Flow credits with separately billed APIs or another provider unless the user starts a separate, explicit request for that route.

## Read-only requests

For feasibility, balance, or capability checks, inspect only the relevant visible UI. Do not create a project, upload references, type into a potentially submitting composer, save settings, start generation, or upscale. Report what was observed and what was not tested. Close any inspection panel you opened when it can be closed without saving; leave the user's tab open.

## Prepare a bounded generation

1. Establish the requested image/video, prompt, project, reference assets, output count, model, ratio, and duration/resolution when the UI offers them. Do not silently substitute unavailable options. Prefer one output for a proposed test, but do not assume the current UI defaults to one.
2. Inspect Flow's Agent confirmation preference without changing it. It must remain **Always / 항상**. Never choose **Never / 안 함**, `AUTO_APPROVE`, or **Approve and don't ask again**. If Always is off or cannot be verified, stop before submission and ask the user to set or verify it themselves; do not save a setting change.
3. Read the selected model, effective output count, and displayed credit estimate from the current UI. Distinguish per-output cost from total cost, generation from upscale, and subscription credits from extra purchases. Check the balance against the total when possible. Use the product's current display instead of hardcoded prices.
4. Record the concrete generation plan in the conversation using the fields below. Show the full final prompt and explain any proposed changes to the user's prompt. Account labels should be minimally identifying; do not reproduce email addresses unless needed to disambiguate.

   | Field | Record before approval |
   | --- | --- |
   | Destination | Visible account/plan and project title or URL |
   | Request | Image/video and exact final prompt |
   | Inputs | Approved reference files, or none |
   | Settings | Exact UI model label, output count, ratio, and available duration/resolution |
   | Cost | Displayed estimate, whether per output or total, and calculated total if applicable |
   | Limit | Maximum credits for this attempt; separate explicit allowance for any upscale |
   | Baseline | Current balance if visible and existing relevant gallery/job state |
   | Delivery | Requested output directory/format, or a proposed writable workspace location |

5. Obtain the user's explicit approval of this bounded plan before the first action that could submit generation or consume credits. A general request to use Flow or to make media is not approval of an undisclosed cost. Existing approval is sufficient only when it clearly covers this exact plan and credit ceiling; do not ask again for an unchanged approved plan.
6. If no reliable current estimate/upper bound is visible, stop before spending and report the missing estimate. Do not guess, run a test to discover the price, top up credits, or upgrade. If a price is first shown on a confirmation screen, reach it only when the current documented/UI flow establishes that doing so cannot start generation; otherwise ask the user to reveal it.

Selecting generation options or uploading user-approved references may be necessary to obtain an estimate. Do so only within the user's requested preparation scope, without changing account preferences or submitting a prompt. An upload is a transmission to Google; use only the specific reference files authorized for Flow. Do not read or upload unrelated files.

## Submit once and track the result

- Immediately before submission, recheck the effective model, count, cost, balance, and unchanged approval scope. A model substitution, higher count, increased cost, or added upscale requires a revised plan and bounded approval.
- Submit the approved request once. Keep Flow's Always preference in place. If Flow presents its own approval card, inspect the actual prompt/settings/cost and use only a one-time approval action covered by the user's approval. If only a persistent approval choice is offered, stop for the user.
- After submitting, record the visible job/card identifier or stable UI link, prompt, submission time, and requested count. Capture the relevant UI baseline before submission so new results can be distinguished from existing assets. Do not invent a job ID or infer identity from gallery order alone.
- On a timeout, tool interruption, navigation, ambiguous click, or missing immediate result, treat submission as **uncertain**. Inspect the same project for a pending/completed/failed item and the displayed balance or credit activity. Wait on the existing job through supported UI observations; never click Generate again just because a response was missing.
- If the outcome cannot be resolved, report the uncertainty and stop. An unresolved attempt has no safe automatic retry. If failure is confirmed, report the displayed failure and any visible charge/refund; obtain fresh bounded approval before a credit-consuming retry. Do not assume a refund has completed.
- Respect rate limits and site restrictions. Do not bypass them or repeatedly resubmit. Do not buy credits. Stop when the approved attempt/count/credit ceiling is reached.

## Download, verify, and report

- Identify the completed asset(s) belonging to the approved attempt from visible job/card context. If association is ambiguous, stop and ask the user to identify the result; do not download an arbitrary latest gallery item.
- Use the supported browser download control/API documented for the selected tab. If available, register `flowTab.playwright.waitForEvent("download")` before clicking the observed download control, then read the returned download path. Follow the current tool's documentation, not assumed Playwright methods. Do not use hidden media URLs, browser session export, or authenticated shell requests.
- Prefer the requested original/download option. Upscaling or regeneration is a separate potentially chargeable action requiring its own inspected estimate and approval. Never choose an upgrade-only option or silently change the requested quality.
- Verify that each downloaded local file exists, is nonempty, and has the expected image/video type. Inspect image dimensions or video metadata with already available local tools when possible. Report which checks were actually done; do not install a decoder merely to complete verification. A thumbnail, screenshot, or success message is not proof of a downloaded original.
- Report the actual prompt/model/settings, requested versus completed/downloaded count, result links/local file paths, displayed cost/charge, and the latest visible remaining balance. Distinguish an estimate from a confirmed charge. A balance difference alone is not proof of this job's charge if other activity could have occurred. Label missing values and pending/failed outputs explicitly.
- Preserve the user's project and existing media. Do not delete failures, rename/move unrelated assets, or close their tab. Retain a page for handoff only according to the browser tool's current lifecycle instructions.

## Reference sources

- [Google Flow credits](https://support.google.com/flow/answer/16526234?hl=en): account credit use and current cost guidance; the live product display governs the plan.
- [Google Flow help](https://support.google.com/flow/answer/16353333?hl=en): access requirements and limitations.

UI access does not prove generation or download success. Browser/session availability, changing UI, account model access, generation queues, and site restrictions can require user intervention. Never promise unattended execution or report media as generated without observing its result.
