# Supported browser workflow

These are entry points verified with Codex's `mcp__cua_repl.js` tool. The documentation returned by the current tool session is authoritative; use only APIs it exposes. Do not import Playwright, launch an independent browser, inspect implementation files for hidden APIs, or use terminal/native automation instead.

## Start or resume

On the first `mcp__cua_repl.js` call, or after a reset, run exactly one documented entry point. When the browser/tab is not yet identified, use:

```javascript
await cua.getState();
```

Read its documentation and browser inventory before the next call. It lists supported browsers and open tabs, not stored authentication data. Do not print unrelated inventory again in the user-facing response.

If continuing from a compacted browser task, call `await cua.rewriteDocumentation()` as instructed by the tool before resuming. Reuse surviving handles when they remain valid.

Choose the browser/tab according to the current tool's selection rules:

- Use the full tab mention if the user supplied one.
- Otherwise bind an existing Flow tab returned by inventory with `cua.getTab(observedTabId, { browser: observedBrowserId })`. Supply actual observed values; never save fixed IDs in this skill.
- The returned binding (for example `flowTab`) includes the initial UI state. Read it before acting.
- Follow any returned Chrome session-naming guidance using the documented browser handle. Session metadata does not authorize changes to site preferences.
- If no Flow tab exists but the selected supported Chrome connection is available, opening `https://flow.google.com/` through the documented `cua.createBrowserTab` entry point is allowed for the requested access check. Provide the documented Chrome session name. Verify the resulting visible page; stop at login or permissions. Do not navigate an unrelated user tab or probe guessed URLs.
- Do not use a fresh in-app browser as if it inherited the user's Chrome login. If Chrome itself is unavailable, report that capability gap.

## Observe and act

- `flowTab.getAXState()` returns accessible UI text. Use fresh element indices from the latest observation for `flowTab.click(index)` or other documented interactions. After an interaction, read fresh state before choosing the next action.
- Use the documented screenshot API only when the accessible state is insufficient or proof of a completed action is needed. Follow current tool instructions for screenshots, saving them only within authorized locations and avoiding unnecessary account details.
- When the selected tab advertises `flowTab.playwright`, semantic locators such as `getByRole` and `getByLabel` can use labels observed in the current UI. DOM snapshots are another supported observation mechanism. API presence in this reference is not a substitute for the session's returned documentation.
- Do not use `evaluate` to read application state, storage, tokens, cookies, network responses, or invoke internal functions. This workflow needs only visible UI observations and documented controls.
- If a click has no clear effect, observe the blocker instead of immediately repeating it. If that click could have submitted a generation, follow the uncertain-submission procedure in `SKILL.md`.
- Never click a saved setting, persistent approval option, Generate, or upscale control during a read-only check. An account details panel can be opened to read balance and then closed without changing settings.

## Downloads and handoff

Use only the download surface advertised by the selected browser. For a tab that documents Playwright download events, register the event before the observed download click, await it, then obtain the path with the documented `download.path` method. Do not invent `saveAs` or filesystem access inside `cua_repl`.

Filesystem verification belongs in normal local file tools after the browser supplies an actual path. If no supported download/path capability exists, report that precise limitation and the visible result link; do not claim a local deliverable or substitute a screenshot.

Follow the browser tool's lifecycle rules for user tabs, temporary tabs, deliverables, and handoffs. Do not close a user-owned Flow tab. When login or approval needs user action, retain the page only through the currently documented handoff mechanism; do not create persistent authentication or export a session.
